package fr.formation.revision;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;

public final class ConnectionManager {

    private String URL = "jdbc:mysql://localhost:3306/mediatheque";
    private String USER = "root";
    private String PASSWORD = "";
    private Connection connection;
    private static ConnectionManager instance;

    private ConnectionManager() {
        loadDriver();
        try {
            this.connection = DriverManager.getConnection(URL,USER,PASSWORD);
            this.connection.setAutoCommit(false);
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Erreur durant la création de la connexion");
        }
    }

    public static ConnectionManager getInstance(){
        if(instance == null) {
            instance = new ConnectionManager();
        }
        return instance;
    }

    private static void loadDriver(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Driver MySQL introuvable");
        }
    }

    public Connection getConnection() {
        return connection;
    }

    public void close(){

    }


}
