package fr.formation.revision;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        MediathequeDAO myMediathequeDAO = new MediathequeDAO();

        boolean exit = false;
        while (!exit) {
            System.out.println("\n### Menu principal ###");
            System.out.println("1. Ajouter un media");
            System.out.println("2. Consulter les médias");
            System.out.println("3. Emprunter un media");
            System.out.println("4. Voir les médias empruntés");
            System.out.println("5. Quitter");

            System.out.print("Veuillez choisir une option : ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    System.out.println("*** AJOUT D'UN MEDIA ****");
                    addMedia(scanner, myMediathequeDAO);
                    break;
                case 2:
                    System.out.println("*** VISUALISER LES MEDIAS ****");
                    viewMedias(scanner, myMediathequeDAO);
                    break;
                case 3:
                    System.out.println("*** EMPRUNTER UN MEDIA ****");
                    borrowMedia(scanner, myMediathequeDAO);
                    break;
                case 4:
                    System.out.println("*** VOIR LES MEDIAS EMPRUNTES ****");
                    viewBorrowedMedias(myMediathequeDAO);
                    break;
                case 5:
                    exit = true;
                    scanner.close();
                    System.out.println("Au revoir !");
                    break;
                default:
                    System.out.println("Option invalide. Merci de réessayer.");
                    break;
            }
        }
    }

    private static void viewBorrowedMedias(MediathequeDAO myMediathequeDAO) {
    }

    private static void borrowMedia(Scanner scanner, MediathequeDAO myMediathequeDAO) {
    }

    private static void viewMedias(Scanner scanner, MediathequeDAO myMediathequeDAO) {
        System.out.println("Quels medias souhaitez-vous consulter ? ");
        Arrays
                .stream(MediaType.values())
                .forEach(m -> System.out.println(m.name()));

        String enumValue = scanner.next().toUpperCase().trim();
        MediaType mediaTypeSelected = MediaType.valueOf(enumValue);

        List<Media> mediaList = myMediathequeDAO.getMedias(mediaTypeSelected);
        mediaList.forEach(media -> System.out.println(media));
    }

    private static void addMedia(Scanner scanner, MediathequeDAO myMediathequeDAO) {
        System.out.println("Quel type de media souhaitez-vous ajouter ? (Saisir)");
        Arrays
                .stream(MediaType.values())
                .forEach(m -> System.out.println(m.name()));

        String enumValue = scanner.nextLine().toUpperCase().trim();
        MediaType mediaTypeSelected = MediaType.valueOf(enumValue);

        Media mediaToAdd = null;
        switch (mediaTypeSelected){
            case BOOK:
            System.out.println("Quel est le nom du livre ?");
            String name = scanner.nextLine();
            System.out.println("Quel est le nombre de pages ?");
            int nbPages = scanner.nextInt();
            System.out.println("Quel est la date de sortie ? (dd/MM/yyyy)");
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            LocalDate releaseDate = LocalDate.parse(scanner.next(), formatter);
            scanner.nextLine();
            System.out.println("Quel est l'auteur ?");
            String author = scanner.nextLine();
            System.out.println("Quel est l'ISBN ?");
            String isbn = scanner.nextLine();
            mediaToAdd = new Book(name, nbPages, isbn, author,releaseDate);
        }


        myMediathequeDAO.addMedia(mediaToAdd);
    }

}
