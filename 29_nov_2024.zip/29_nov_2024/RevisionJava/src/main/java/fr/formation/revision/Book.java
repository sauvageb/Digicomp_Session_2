package fr.formation.revision;

import java.time.LocalDate;

public class Book extends Media {

    private String isbn;
    private int numberPages;

    public Book(String title, int numberPages, String isbn, String author, LocalDate releaseDate) {
        super(title, MediaType.BOOK, author, releaseDate);
        this.numberPages = numberPages;
        this.isbn = isbn;
    }

    public String getIsbn() {
        return isbn;
    }

    public int getNumberPages() {
        return numberPages;
    }

    @Override
    public String toString() {
        return "Book{" +
                "isbn='" + isbn + '\'' +
                ", numberPages=" + numberPages +
                "} " + super.toString();
    }
}
