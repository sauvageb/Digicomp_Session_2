package fr.formation.revision;

import java.nio.channels.InterruptibleChannel;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

// Design Pattern
// DAO : Data Access Object
// Couche d'accès aux données
// CRUD : Create Read Update Delete
public class MediathequeDAO {

    public void addMedia(Media mediaToAdd) {
        String querySql = "INSERT INTO medias (id, title, type, author, release_date) VALUES (?,?,?,?,?)";
        Connection connection = ConnectionManager.getInstance().getConnection();

        try (PreparedStatement preparedStatement = connection.prepareStatement(querySql)) {
            preparedStatement.setString(1, mediaToAdd.getId().toString());
            preparedStatement.setString(2, mediaToAdd.getTitle());
            preparedStatement.setString(3, mediaToAdd.getType().name());
            preparedStatement.setString(4, mediaToAdd.getAuthor());
            preparedStatement.setDate(5, Date.valueOf(mediaToAdd.getReleaseDate()));
            preparedStatement.executeUpdate();

            if (mediaToAdd.getType() == MediaType.BOOK) {
                Book bookToAdd = (Book) mediaToAdd;
                String bookQuery = "INSERT INTO books (id, isbn, number_pages) VALUES (?,?,?)";
                try (PreparedStatement pst = connection.prepareStatement(bookQuery)) {
                    pst.setString(1, bookToAdd.getId().toString());
                    pst.setString(2, bookToAdd.getIsbn());
                    pst.setInt(3, bookToAdd.getNumberPages());
                    pst.executeUpdate();
                }
            }

            connection.commit();

        } catch (SQLException e1) {
            e1.printStackTrace();

            try {
                connection.rollback();
            } catch (SQLException e2) {
                e2.printStackTrace();
            }
        }
    }

    public List<Media> getMedias(MediaType mediaTypeFilter) {
        List<Media> mediaList = new ArrayList<>();
        String query = "SELECT m.id, m.title, m.type, m.author, m.release_date, b.isbn, b.number_pages " +
                "FROM medias m " +
                "JOIN books b ON m.id = b.id WHERE m.type = ?";
        Connection connection = ConnectionManager.getInstance().getConnection();
        try (PreparedStatement pst = connection.prepareStatement(query)) {
            pst.setString(1, mediaTypeFilter.name());
            ResultSet resultSet = pst.executeQuery();

            while (resultSet.next()) {
                MediaType type = Enum.valueOf(MediaType.class, resultSet.getString("type"));
                if(type == MediaType.BOOK){
                    Media book = new Book(
                            resultSet.getString("title"),
                            resultSet.getInt("number_pages"),
                            resultSet.getString("isbn"),
                            resultSet.getString("author"),
                            resultSet.getObject("release_date", LocalDate.class)
                    );
                    book.setId(UUID.fromString(resultSet.getString("id")));
                    mediaList.add(book);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return mediaList;
    }
}
