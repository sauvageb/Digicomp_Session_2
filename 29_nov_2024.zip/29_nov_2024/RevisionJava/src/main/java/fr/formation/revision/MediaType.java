package fr.formation.revision;

public enum MediaType {
    BOOK,
    VIDEO,
    AUDIO
}
