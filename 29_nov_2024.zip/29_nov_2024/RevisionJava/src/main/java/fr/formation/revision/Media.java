package fr.formation.revision;

import java.time.LocalDate;
import java.util.UUID;

public abstract class Media {
    private UUID id;
    private String title;
    private MediaType type;
    private String author;
    private LocalDate releaseDate;

    public Media(String title, MediaType type, String author, LocalDate releaseDate) {
        this.id = UUID.randomUUID();
        this.title = title;
        this.type = type;
        this.author = author;
        this.releaseDate = releaseDate;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public UUID getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public LocalDate getReleaseDate() {
        return releaseDate;
    }

    public MediaType getType() {
        return type;
    }

    @Override
    public String toString() {
        return "Media{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", type=" + type +
                ", author='" + author + '\'' +
                ", releaseDate=" + releaseDate +
                '}';
    }
}
