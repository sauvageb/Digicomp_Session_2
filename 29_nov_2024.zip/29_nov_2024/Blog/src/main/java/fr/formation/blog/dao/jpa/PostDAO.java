package fr.formation.blog.dao.jpa;

import fr.formation.blog.dao.entity.Post;

import java.util.List;

public interface PostDAO {

    Post save(Post post);

    List<Post> fetchAll();

}
