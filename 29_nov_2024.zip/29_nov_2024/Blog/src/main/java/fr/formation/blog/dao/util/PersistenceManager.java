package fr.formation.blog.dao.util;

import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public final class PersistenceManager {

        private EntityManagerFactory emf;
        private static volatile PersistenceManager instance;

        private PersistenceManager() {
            this.emf = Persistence.createEntityManagerFactory("blog-pu");
        }

        public static PersistenceManager getInstance() {
            if (instance == null) {
                synchronized (PersistenceManager.class) {
                    if (instance == null) {
                        instance = new PersistenceManager();
                    }
                }
            }
            return instance;
        }

        public EntityManagerFactory get() {
            return this.emf;
        }

        public void close() {
            if (this.emf != null && this.emf.isOpen()) {
                this.emf.close();
            }
        }
    }
