package fr.formation.blog;

import fr.formation.blog.dao.entity.Comment;
import fr.formation.blog.dao.entity.Post;
import fr.formation.blog.dao.jpa.PostDAO;
import fr.formation.blog.dao.jpa.PostJpaDAO;
import fr.formation.blog.dao.util.PersistenceManager;

import java.time.Instant;

public class Main {

    public static void main(String[] args) {
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            System.out.println("Closing Connection..");
            PersistenceManager.getInstance().close();
        }));

        PostDAO postDAO = new PostJpaDAO(PersistenceManager.getInstance());

        // SELECT
        postDAO.fetchAll().forEach(p -> System.out.println(p));

        // INSERT
        Post p1 = new Post("Post1", "Description1", Instant.now());
        p1.addComment(new Comment("Super post !"));
        postDAO.save(p1);
    }
}
