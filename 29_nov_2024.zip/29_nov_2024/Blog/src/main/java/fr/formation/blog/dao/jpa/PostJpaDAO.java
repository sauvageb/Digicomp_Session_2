package fr.formation.blog.dao.jpa;

import fr.formation.blog.dao.entity.Comment;
import fr.formation.blog.dao.entity.Post;
import fr.formation.blog.dao.util.PersistenceManager;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.TypedQuery;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

public class PostJpaDAO implements PostDAO {

    private PersistenceManager persistenceManager;

    public PostJpaDAO(PersistenceManager persistenceManager) {
        this.persistenceManager = persistenceManager;
    }

    @Override
    public List<Post> fetchAll() {
        try (EntityManager em = persistenceManager.get().createEntityManager()) {
            TypedQuery<Post> query = em.createQuery("SELECT p FROM Post p", Post.class);
            return query.getResultList();
        } catch (Exception e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    @Override
    public Post save(Post post) {
        EntityManager em = persistenceManager.get().createEntityManager();
        EntityTransaction transaction = em.getTransaction();
        try {
            transaction.begin();
            em.persist(post);
            transaction.commit();
            return post;
        } catch (Exception e) {
            e.printStackTrace();
            if (transaction.isActive()) {
                transaction.rollback();
            }
            throw new RuntimeException("cannot add post");
        } finally {
            em.close();
        }

    }
}
