package fr.formation.exercices;

import java.util.OptionalInt;
import java.util.Random;
import java.util.function.IntConsumer;
import java.util.stream.IntStream;

public class ExerciceEnsemble {

    public static void main(String[] args) {
        int[] values = new Random()
                .ints(6, 0, 20)
                .toArray();

        // Question 1
        IntStream.of(values)
                .sorted()
                .forEach(x -> System.out.println(x));

        // Question 2
        IntStream.of(values)
                .sorted()
                .findFirst()
                .ifPresent(x -> System.out.println(x));

        // Question 3
        int sum = IntStream.of(values)
                .filter(value -> value > 3)
                .sum();
        System.out.println(sum);
    }
}
