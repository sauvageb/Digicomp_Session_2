package exercices.stream;

import java.util.Comparator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import static java.util.Arrays.asList;

/*
 ** Consigne **
 *
 * Avec les Streams, codez getOldestPersonWithStream pour récupérer la personne la plus âgée de la liste
 * Elle devra avoir le même comportement que getOldestPerson
 *
 *************
 *
 * Resultat attendu : exercices.stream.Person{name='Eva', age=42, nationality=''}
 *
 */
public class Exo4 {

    public static void main(String[] args) {
        Person sara = new Person("Sara", 4);
        Person viktor = new Person("Viktor", 40);
        Person eva = new Person("Eva", 42);
        List<Person> persons = asList(sara, eva, viktor);

        Person olderPerson = getOldestPerson(persons);
        System.out.println(olderPerson);
    }

    public static Person getOldestPerson(List<Person> people) {
        Person oldestPerson = new Person("", 0);
        for (Person person : people) {
            if (person.getAge() > oldestPerson.getAge()) {
                oldestPerson = person;
            }
        }
        return oldestPerson;
    }

    public static Person getOldestPersonWithStream(List<Person> people) {
        Person person2 = people
                .stream()
                .reduce((p1, p2) -> p1.getAge() >= p2.getAge() ? p1 : p2)
                .orElseThrow(() -> new NoSuchElementException("No people found"));

         people
                .stream()
                .sorted(Comparator.comparingInt(Person::getAge))
                .findFirst().get();


         return people
                .stream()
                .max((p1, p2) -> p1.getAge() - p2.getAge())
                .orElseThrow(() -> new NoSuchElementException("No people found"));
    }
}

