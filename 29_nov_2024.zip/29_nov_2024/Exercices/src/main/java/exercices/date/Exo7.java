package exercices.date;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;

/*
 ** Consigne **
 *
 * La fusée décolle dans 3 jours et 5h. Affichez la date et l'horaire de décollage
 *
 *************
 *
 * Resultat attendu :
 */
class Exo7 {

    public static void main(String[] args) {
        System.out.println("Date et heure exacte du décollage :" + rocketStartup());
    }

    public static LocalDateTime rocketStartup() {
        return LocalDateTime
                .now()
                .plusDays(3).plusHours(5);
    }

}
