package exercices.date;

/*
 ** Consigne **
 *
 * Vous souhaitez partir fin février de l'année prochaine, mais vous avez besoin de savoir si l'année prochaine
 *  est bissextile.
 *
 * Affichez le résultat
 *
 *************
 *
 * Resultat attendu :
 */
class Exo11 {

    public static void main(String[] args) {
        Object date1 = null;

//        if(date1 ...date2){
//            System.out.println("L'année " + year + " est bissextile");
//        }else{
//            System.out.println("L'année " + year + " n'est pas bissextile");
//        }
    }
}

