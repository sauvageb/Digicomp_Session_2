package exercices.date;

import java.time.LocalDate;

/*
 ** Consigne **
 *
 * Afficher l'année, le mois et le jour de l'année du jour
 *
 *************
 *
 */
class Exo2 {

    public static void main(String[] args) {
        Object today = getToday();
        int year = 0;
        int month = 0;
        int day = 0;
        System.out.println("année:" + year);
        System.out.println("mois:" + month);
        System.out.println("jour:" + day);
    }


    // TODO : le type de retour doit être modifié
    public static Object getToday() {
        return null;
    }

}
