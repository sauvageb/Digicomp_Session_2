package exercices.date;

/*
 ** Consigne **
 *
 * Nous essayons de savoir programmatiquement si une date est avant ou après une autre. Affichez un message pour
 * indiquer les cas.
 *
 * date 1 : aujourd'hui
 * date 2 : 22 02 2022
 *
 *
 * ASTUCE : Vous devez utiliser isAfter ou isBefore
 *
 *************
 *
 * Resultat attendu :
 */
class Exo10 {

    public static void main(String[] args) {
        Object date1 = null;
        Object date2 = null;

//        if(date1 ...date2){
//            System.out.println("message");
//        }else{
//            System.out.println("message");
//        }
    }

}
