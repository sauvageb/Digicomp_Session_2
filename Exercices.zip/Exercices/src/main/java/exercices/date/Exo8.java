package exercices.date;

/*
 ** Consigne **
 *
 * 1) Vos amis souhaitent vous rencontrer dans une semaine. Quelle sera la date ?
 *
 * 2) Après discussion au téléphone, ils vous disent que la dernière fois qu'ils vous ont vu, c'etait il y a 1 an exactement
 * Quelle était cette date ?
 *
 * ASTUCE : Vous devez utiliser la classe ChronoUnit
 *
 *************
 *
 * Resultat attendu :
 */
class Exo8 {

    public static void main(String[] args) {
        //        1)
        Object today = null;
        System.out.println("La date du jour est : " + today);
        Object nextWeek = null;
        System.out.println("La date après un \"week\" est : " + nextWeek);

        //        2)
        Object lastTime = null;
        System.out.println("La date à laquelle nous nous sommes vu est le  : " + lastTime);
    }

}
