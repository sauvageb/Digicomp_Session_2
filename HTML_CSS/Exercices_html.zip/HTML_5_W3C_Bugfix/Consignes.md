Ce document contient plusieurs erreurs 💥. Vous pouvez les détécter à l'aide de Markup Validation Service W3c

https://validator.w3.org/#validate_by_input 

------------------
🤔Comment procéder :

Utiliser le fichier HTML dans le Validator.

Vous pouvez effecturer des corrections directement dans le validateur ou bien dans votre HTML

*/
